package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//@WebFilter("/Menufilter")
public class Menufilter implements Filter {

	@Override
	public void init(FilterConfig config)throws ServletException{}
	@Override
	public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)
		throws IOException,ServletException{

		HttpServletRequest httpRequest =(HttpServletRequest) request;
		HttpSession session = httpRequest.getSession(true);

		//ログインしている場合。
		if(session.getAttribute("password") != null ){
			chain.doFilter(request, response);

		//ログインせずにアクセスした場合。
		}else {
			request.setAttribute("error", "こちらから、ログインしてください。");
			RequestDispatcher rd = request.getRequestDispatcher("./login.jsp");
			rd.forward(request, response);
		}
	}
	@Override
	public void destroy() {}
}
