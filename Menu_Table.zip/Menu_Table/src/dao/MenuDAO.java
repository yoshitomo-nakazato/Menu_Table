package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MenuDAO {

	private static final String URL = "jdbc:mysql://localhost/store";
	private static final String USER = "root";
	private static final String PASSWORD = "";

	//売上の登録（IDは自動生成）
	public int totalSales(int sales,int taxSum,int totalAll,int tax,int cash,int credit,int point,String date) {

		String sql="INSERT INTO totalsales(sales,taxsum,totalsales,tax,cash,credit,point,date) VALUES(?,?,?,?,?,?,?,?)";

		Connection con = null;
		PreparedStatement ps = null;

		int result = -1;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setInt(1,sales);			//売上
			ps.setInt(2,taxSum);		//消費税合計
			ps.setInt(3,totalAll);		//売上合計
			ps.setInt(4,tax);			//消費税
			ps.setInt(5,cash);			//現金
			ps.setInt(6,credit);		//クレジット
			ps.setInt(7,point);			//ポイント（その他）
			ps.setString(8,date);		//日付
			result = ps.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
					ps.close();
					con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	//売上idの確認
	public int confirmation(int totalAll,String date) {

		String sql="SELECT * FROM totalsales WHERE totalsales=? and date=?";

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		int id = 0;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setInt(1,totalAll);		//売上
			ps.setString(2,date);		//日付
			rs = ps.executeQuery();

			if(rs.next()) {
				id = rs.getInt("id");
			}

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
					ps.close();
					con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return id;
	}

	//ハンバーガーの売上登録
	public int insertBuger(int id,String burger,int burgerPrice,int burgerCount,String date) {

		String sql="INSERT INTO burgersales(id,burger_name,price,count,date) VALUES(?,?,?,?,?)";

		Connection con = null;
		PreparedStatement ps = null;

		int result = -1;

		try {
			//DBに接続
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			//スタートメントを生成
			ps = con.prepareStatement(sql);
			//?に値をセット
			ps.setInt(1,id);				//id
			ps.setString(2,burger);			//商品名
			ps.setInt(3,burgerPrice);		//単価
			ps.setInt(4,burgerCount);		//個数
			ps.setString(5,date);			//日付
			result = ps.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			//リソースを解放
			try {
					ps.close();
					con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

		//サイドメニューの売上登録
		public int insertSideMenu(int id,String sideMenu,int sideMenuPrice,String sideMenuSize,int sideMenuCount,String date) {

			String sql="INSERT INTO sidemenusales(id,sidemenu_name,price,sidemenu_size,count,date) VALUES(?,?,?,?,?,?)";

			Connection con = null;
			PreparedStatement ps = null;

			int result = -1;

			try {
				//DBに接続
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(URL, USER, PASSWORD);
				//スタートメントを生成
				ps = con.prepareStatement(sql);
				//?に値をセット
				ps.setInt(1,id);				//id
				ps.setString(2,sideMenu);		//商品名
				ps.setInt(3,sideMenuPrice);		//単価
				ps.setString(4,sideMenuSize);	//サイズ
				ps.setInt(5,sideMenuCount);		//個数
				ps.setString(6,date);			//日付
				result = ps.executeUpdate();

			}catch (Exception e) {
				e.printStackTrace();
			} finally {
				//リソースを解放
				try {
						ps.close();
						con.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return result;
	}
		//ドリンクの売上登録
		public int insertDrink(int id,String drink,int drinkPrice,String drinkSize,int drinkCount,String date) {

			String sql="INSERT INTO drinksales(id,drink_name,price,drink_size,count,date) VALUES(?,?,?,?,?,?)";

			Connection con = null;
			PreparedStatement ps = null;

			int result = -1;

			try {
				//DBに接続
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(URL, USER, PASSWORD);
				//スタートメントを生成
				ps = con.prepareStatement(sql);
				//?に値をセット
				ps.setInt(1,id);				//id
				ps.setString(2,drink);		//商品名
				ps.setInt(3,drinkPrice);		//単価
				ps.setString(4,drinkSize);	//サイズ
				ps.setInt(5,drinkCount);		//個数
				ps.setString(6,date);			//日付
				result = ps.executeUpdate();

			}catch (Exception e) {
				e.printStackTrace();
			} finally {
				//リソースを解放
				try {
						ps.close();
						con.close();

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return result;
	}
}
