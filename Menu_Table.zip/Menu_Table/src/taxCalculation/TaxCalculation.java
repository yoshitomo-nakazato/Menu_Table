package taxCalculation;

public class TaxCalculation {

	//税込価格を計算する処理
	public int  taxPrice(int price,int tax){

		double taxdouble = price + price*tax/100 ;

		int taxPrice = (int)taxdouble;

		return taxPrice;
	}

}
