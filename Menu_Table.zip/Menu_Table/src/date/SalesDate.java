package date;

import java.util.Calendar;

public class SalesDate {

	public String dateRegist() {

	String Salesdate = null;
	//インスタンス取得メソッド
	Calendar cal = Calendar.getInstance();

	//西暦を取得してyearに格納している
	int year = cal.get(Calendar.YEAR);
	String yearStr = String.valueOf(year);

	//月を取得してmonthに格納している（monthには+1が必要）
	int month = cal.get(Calendar.MONTH) + 1;
	String monthStr = String.valueOf(month);

	//日付を取得してdayに格納している。
	int day = cal.get(Calendar.DAY_OF_MONTH);
	String dayStr = String.valueOf(day);
	//時刻を取得してhourに格納している。
	int hour = cal.get(Calendar.HOUR_OF_DAY);
	String hourStr = String.valueOf(hour);
	//分を取得してminuteに格納している。
	int minute = cal.get(Calendar.MINUTE);
	String minuteStr = String.valueOf(minute);

	//曜日を配列に格納する（システム上、土曜日から格納しないと日付がずれる
	//0⇒土曜日、1⇒日曜日、、、6⇒金曜日
	String []week= {"土","日","月","火","水","木","金"};
	//DAY_OF_WEEKで取得した数字と上記の配列番号に間違いがなければ正しい曜日を取得できる。
	String weekday=week[cal.get(Calendar.DAY_OF_WEEK)];

	Salesdate = yearStr+"年"+monthStr+"月"+dayStr+"日（"+weekday+"）"+hourStr+":"+minuteStr;

	return Salesdate;

	}
}
