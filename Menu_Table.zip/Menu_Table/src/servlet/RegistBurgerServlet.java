package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.MenuEntity;

//@WebServlet("/RegistBugerServlet")
public class RegistBurgerServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true);

		String burger = request.getParameter("burger");
		String burgerPricestr = request.getParameter("burgerPrice");
		Integer burgerPrice = Integer.parseInt(burgerPricestr);
		String burgerCountstr = request.getParameter("burgerCount");
		Integer burgerCount = Integer.parseInt(burgerCountstr);

		MenuEntity burgermenu = new MenuEntity();
		List<MenuEntity> listbuger =(List<MenuEntity>)session.getAttribute("listbuger");

		//初回リスト登録
		if(listbuger == null) {
			listbuger =new ArrayList<MenuEntity>();
			burgermenu.setBurger(burger);
			burgermenu.setBurgerPrice(burgerPrice);
			burgermenu.setBurgerCount(burgerCount);
			listbuger.add(burgermenu);

		//２回目以降
		}else {
			listbuger = (List<MenuEntity>)session.getAttribute("listbuger");
			burgermenu.setBurger(burger);
			burgermenu.setBurgerPrice(burgerPrice);
			burgermenu.setBurgerCount(burgerCount);
			listbuger.add(burgermenu);
		}

		session.setAttribute("listbuger",listbuger);
		request.setAttribute("message","商品を買い物カゴに追加しました。");
		RequestDispatcher rd = request.getRequestDispatcher("./additionMenu.jsp");
		rd.forward(request, response);

	}
}
