package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.MenuEntity;
import taxCalculation.TaxCalculation;

//@WebServlet("/CalculationServlet")
public class CalculationServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true);

		List<MenuEntity> listbuger = (List<MenuEntity>) session.getAttribute("listbuger");
		List<MenuEntity> listsideMenu =(List<MenuEntity>)session.getAttribute("listsideMenu");
		List<MenuEntity> listdrink =(List<MenuEntity>)session.getAttribute("listdrink");

		//deletServletから来た時の為に用意
		String deleteMessage = (String)request.getAttribute("deleteMessage");

		Integer tax = (Integer) session.getAttribute("tax");
		MenuEntity bugerMenu = new MenuEntity();
		MenuEntity sideMenu = new MenuEntity();
		MenuEntity drinkMenu = new MenuEntity();

		int i = 0;
		int burgerSum = 0;
		int burgerSumTax = 0;

		int sideMenuSum = 0;
		int sideMenuSumTax = 0;

		int drinkSum = 0;
		int drinkSumTax = 0;

		int totalAll = 0;
		String message = null;
		String url = "./additionMenu.jsp";

		//paymentSelect（会計時）から来た時に使用する
		String combo = request.getParameter("combo");

		//全てのリストのnull確認
		if (listbuger == null&&listsideMenu == null&&listdrink == null) {
			message = "買い物カゴに商品の登録はありません。";
			url = "./additionMenu.jsp";

		//リストに商品の登録があった際の処理
		} else {
			TaxCalculation taxCalculation = new TaxCalculation();

			//ハンバーガーのリスト確認
			if(listbuger != null) {

			for (i = 0; i < listbuger.size(); i++) {
				bugerMenu = listbuger.get(i);

				//消費税抜きの計算
				burgerSum = burgerSum + bugerMenu.getBurgerPrice() * bugerMenu.getBurgerCount();
				//消費税込の計算
				burgerSumTax = burgerSumTax
						+ taxCalculation.taxPrice(bugerMenu.getBurgerPrice() * bugerMenu.getBurgerCount(), tax);
			}
			}
			//サイドメニューのリスト確認
			if(listsideMenu != null) {
			for (i = 0;i < listsideMenu.size();i++) {
				sideMenu = listsideMenu.get(i);

				//消費税抜きの計算
				sideMenuSum = sideMenuSum + sideMenu.getSideMenuPrice()*sideMenu.getSideMenuCount();
				//消費税込の計算
				sideMenuSumTax = sideMenuSumTax
						+ taxCalculation.taxPrice(sideMenu.getSideMenuPrice()*sideMenu.getSideMenuCount(),tax);
			}
			}
			//ドリンクのリスト確認
			if(listdrink != null) {
			for (i = 0;i < listdrink.size();i++) {
				drinkMenu = listdrink.get(i);

				//消費税抜きの計算
				drinkSum = drinkSum + drinkMenu.getDrinkPrice()*drinkMenu.getDrinkCount();
				//消費税込の計算
				drinkSumTax = drinkSumTax
						+ taxCalculation.taxPrice(drinkMenu.getDrinkPrice()*drinkMenu.getDrinkCount(),tax);
			}
			}
			url = "./shoppingbasket.jsp";
		}

		totalAll = burgerSumTax+sideMenuSumTax+drinkSumTax;

		//paymentSelectから来た時にpaymentSelectCombo_1.jspへ戻す
		if(combo != null) {
			url = "./paymentSelectCombo_1.jsp";
		}

		//deleteServletからの来た時の為に用意
		request.setAttribute("deleteMessage", deleteMessage);

		request.setAttribute("message", message);
		session.setAttribute("tax", tax);

		session.setAttribute("listbuger", listbuger);
		request.setAttribute("burgerSum", burgerSum);
		request.setAttribute("burgerSumTax", burgerSumTax);

		session.setAttribute("listsideMenu", listsideMenu);
		request.setAttribute("sideMenuSum", sideMenuSum);
		request.setAttribute("sideMenuSumTax", sideMenuSumTax);

		session.setAttribute("listdrink", listdrink);
		request.setAttribute("drinkSum", drinkSum);
		request.setAttribute("drinkSumTax", drinkSumTax);

		request.setAttribute("totalAll", totalAll);

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}
}
