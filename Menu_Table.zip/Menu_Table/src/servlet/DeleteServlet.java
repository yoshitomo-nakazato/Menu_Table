package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.MenuEntity;

/**
 * Servlet implementation class DeleteServlet
 */
//@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true);

		List<MenuEntity> listbuger =(List<MenuEntity>)session.getAttribute("listbuger");
		List<MenuEntity> listsideMenu =(List<MenuEntity>)session.getAttribute("listsideMenu");
		List<MenuEntity> listdrink =(List<MenuEntity>)session.getAttribute("listdrink");
		String burger = request.getParameter("burger");
		String sideMenu = request.getParameter("sideMenu");
		String drink = request.getParameter("drink");
		String deleteMessage = null;

		//各リストの中身をnullに置き換える処理
		if(burger != null) {
			//listbuger.clear();
			deleteMessage = "ハンバーガーの商品をリストから削除しました。";
			listbuger = null;
		}else if(sideMenu != null) {
			//listsideMenu.clear();
			deleteMessage = "サイドメニューの商品をリストから削除しました。";
			listsideMenu = null;
		}else if(drink != null){
			//listdrink.clear();
			deleteMessage = "ドリンクの商品をリストから削除しました。";
			listdrink = null;
		}

		session.setAttribute("listbuger",listbuger);
		session.setAttribute("listsideMenu",listsideMenu);
		session.setAttribute("listdrink",listdrink);
		request.setAttribute("deleteMessage",deleteMessage);

		RequestDispatcher rd = request.getRequestDispatcher("./additionMenu.jsp");
		rd.forward(request, response);
	}
}
