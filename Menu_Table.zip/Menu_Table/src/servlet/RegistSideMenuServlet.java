package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.MenuEntity;

//@WebServlet("/RegistSideMenuServlet")
public class RegistSideMenuServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true);

		String sideMenu = request.getParameter("sideMenu");
		String sideMenuPricestr = request.getParameter("sideMenuPrice");
		String sideMenuSize = request.getParameter("sideMenuSize");
		Integer sideMenuPrice = Integer.parseInt(sideMenuPricestr);
		String sideMenuCountstr = request.getParameter("sideMenuCount");
		Integer sideMenuCount = Integer.parseInt(sideMenuCountstr);

		MenuEntity sidemenu = new MenuEntity();
		List<MenuEntity> listsideMenu =(List<MenuEntity>)session.getAttribute("listsideMenu");

		//初回リスト登録
		if(listsideMenu == null) {
			listsideMenu =new ArrayList<MenuEntity>();
			sidemenu.setSideMenu(sideMenu);
			sidemenu.setSideMenuSize(sideMenuSize);
			sidemenu.setSideMenuPrice(sideMenuPrice);
			sidemenu.setSideMenuCount(sideMenuCount);
			listsideMenu.add(sidemenu);

		//２回目以降
		}else {
			listsideMenu = (List<MenuEntity>)session.getAttribute("listsideMenu");
			sidemenu.setSideMenu(sideMenu);
			sidemenu.setSideMenuSize(sideMenuSize);
			sidemenu.setSideMenuPrice(sideMenuPrice);
			sidemenu.setSideMenuCount(sideMenuCount);
			listsideMenu.add(sidemenu);
		}
		session.setAttribute("listsideMenu",listsideMenu);
		request.setAttribute("message","商品を買い物カゴに追加しました。");
		RequestDispatcher rd = request.getRequestDispatcher("./additionMenu.jsp");
		rd.forward(request, response);
	}
}
