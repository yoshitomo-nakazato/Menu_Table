package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/PaymentInputCheckServlet")
public class PaymentInputCheckServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//paymentSelectCombo_1.jspから送られてきた数値のチェックを行うクラス

		request.setCharacterEncoding("UTF-8");

		String totalAllstr = request.getParameter("totalAll");
		int totalAll = Integer.parseInt(totalAllstr);
		String creditstr = request.getParameter("credit");
		String pointstr = request.getParameter("point");
		String message = null;

		int credit = 0;
		int point = 0;
		int cash = 0;
		String url = "";

		if (creditstr == null && pointstr == null) {
			message = "クレジット及びポイントに入力がありません。再度入力してください。";
			cash = totalAll;
			url = "./paymentSelectCombo_1.jsp";
		} else if (creditstr.equals("") || pointstr.equals("")) {
			message = "クレジット及びポイントに入力がありません。再度入力してください。";
			url = "./paymentSelectCombo_1.jsp";
			cash = totalAll;
		} else {
			try {
				credit = Integer.parseInt(creditstr);
				point = Integer.parseInt(pointstr);

				if (totalAll < credit + point) {
					message = "クレジット+ポイントの合計金額が、請求金額より多くなっています！再度入力してください。";
					url = "./paymentSelectCombo_1.jsp";
				} else {
					//合計金額からクレジット+ポイントを引いた金額を現金支払いに割り振る
					cash = totalAll - credit - point;
					url = "./paymentSelectCombo_2.jsp";
				}

			} catch (NumberFormatException e) {
				message = "整数でない箇所がありました。再度入力してください。";
				url = "./paymentSelectCombo_1.jsp";
			}
		}

		request.setAttribute("message", message);
		request.setAttribute("credit", credit);
		request.setAttribute("point", point);
		request.setAttribute("cash", cash);
		request.setAttribute("totalAll", totalAll);

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}
}
