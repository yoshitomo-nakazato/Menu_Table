package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);

		//IDとPASSのnull及び空白チェック

		String id = request.getParameter("id");
		//idにnullと空がないことを確認。
		if(id==null ||id=="") {
			request.setAttribute("message","ID又はパスワードを入力してください。");
			RequestDispatcher rd = request.getRequestDispatcher("./login.jsp");
			rd.forward(request, response);
		}

		String password = request.getParameter("password");
		//passwordにnullと空がないことを確認。
		if(password==null ||password=="") {
			request.setAttribute("message","ID又はパスワードを入力してください。");
			RequestDispatcher rd = request.getRequestDispatcher("./login.jsp");
			rd.forward(request, response);
		}

		//IDとPASSの内容確認
		String message = null;
		String url = null;

		if (password.equals("admin")&&id.equals("admin")) {
			session = request.getSession(true);
			url = "./top.jsp";
			message = "ログインに成功しました。";
			session.setAttribute("password", password);

		}else {
			url = "./login.jsp";
			message ="ＩＤ又はパスワードに誤りがあります。";
		}

		request.setAttribute("message", message);

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}
}