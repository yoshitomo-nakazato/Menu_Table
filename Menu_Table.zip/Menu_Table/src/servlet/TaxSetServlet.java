package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//@WebServlet("/TaxSetServlet")
public class TaxSetServlet extends HttpServlet {

	//消費税を８％か１０％を設定する処理
	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true);

		String taxstr = request.getParameter("tax");
		Integer tax = Integer.parseInt(taxstr);

		session.setAttribute("tax",tax);

		RequestDispatcher rd = request.getRequestDispatcher("./ｍenu.jsp");
		rd.forward(request, response);

	}
}
