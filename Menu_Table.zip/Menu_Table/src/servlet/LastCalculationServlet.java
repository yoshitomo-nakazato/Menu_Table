package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.MenuDAO;
import date.SalesDate;
import entity.MenuEntity;
import taxCalculation.TaxCalculation;

//@WebServlet("/LastCalculationServlet")
public class LastCalculationServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true);

		List<MenuEntity> listbuger = (List<MenuEntity>) session.getAttribute("listbuger");
		List<MenuEntity> listsideMenu = (List<MenuEntity>) session.getAttribute("listsideMenu");
		List<MenuEntity> listdrink = (List<MenuEntity>) session.getAttribute("listdrink");
		MenuEntity bugerMenu = new MenuEntity();
		MenuEntity sideMenu = new MenuEntity();
		MenuEntity drinkMenu = new MenuEntity();
		Integer tax = (Integer) session.getAttribute("tax");

		String cashstr = request.getParameter("cash");
		Integer cash = Integer.parseInt(cashstr);

		String creditstr = request.getParameter("credit");
		Integer credit = Integer.parseInt(creditstr);

		String pointstr = request.getParameter("point");
		Integer point = Integer.parseInt(pointstr);

		String totalAllstr = request.getParameter("totalAll");
		Integer totalAll = Integer.parseInt(totalAllstr);

		int burgerSum = 0;
		int burgerSumTax = 0;
		String messageBurgerComplet = null;

		int sideMenuSum = 0;
		int sideMenuSumTax = 0;
		String messageSideMenuComplet = null;

		int drinkSum = 0;
		int drinkSumTax = 0;
		String messageDrinkComplet = null;

		String message = null;
		String error = null;

		TaxCalculation taxCalculation = new TaxCalculation();

		//ハンバーガーのリスト確認
		if (listbuger != null) {

			for (int i = 0; i < listbuger.size(); i++) {
				bugerMenu = listbuger.get(i);

				//消費税抜きの計算
				burgerSum = burgerSum + bugerMenu.getBurgerPrice() * bugerMenu.getBurgerCount();
				//消費税込の計算
				burgerSumTax = burgerSumTax	+ taxCalculation.taxPrice(bugerMenu.getBurgerPrice() * bugerMenu.getBurgerCount(), tax);

			}
		}

		//サイドメニューのリスト確認
		if (listsideMenu != null) {
			for (int i = 0; i < listsideMenu.size(); i++) {
				sideMenu = listsideMenu.get(i);

				//消費税抜きの計算
				sideMenuSum = sideMenuSum + sideMenu.getSideMenuPrice() * sideMenu.getSideMenuCount();
				//消費税込の計算
				sideMenuSumTax = sideMenuSumTax
						+ taxCalculation.taxPrice(sideMenu.getSideMenuPrice() * sideMenu.getSideMenuCount(), tax);
			}
		}

		//ドリンクのリスト確認
		if (listdrink != null) {
			for (int i = 0; i < listdrink.size(); i++) {
				drinkMenu = listdrink.get(i);

				//消費税抜きの計算
				drinkSum = drinkSum + drinkMenu.getDrinkPrice() * drinkMenu.getDrinkCount();
				//消費税込の計算
				drinkSumTax = drinkSumTax
						+ taxCalculation.taxPrice(drinkMenu.getDrinkPrice() * drinkMenu.getDrinkCount(), tax);
			}
		}

		//税抜き価格の合計と消費税合計の計算
		int sales = burgerSum + sideMenuSum + drinkSum ;
		int taxSum = totalAll - burgerSum - sideMenuSum - drinkSum ;

		//----------------売上をDBに登録する----------------------
		MenuDAO dao = new MenuDAO();
		//曜日の取得
		SalesDate saledate = new SalesDate();
		String date = saledate.dateRegist();
		//売上をDBに登録
		int result = dao.totalSales(sales, taxSum, totalAll, tax, cash, credit, point, date);
		message ="DBへ売上登録に成功しました。";
		//売上登録後にIDをDBより取得
		if(result == 1) {
			//売上登録後にidを取得する
			int id = dao.confirmation(totalAll,date);

			//----------------ハンバーガー売上をDBに登録する----------------------
			//取得した売上idを使用してハンバーガー売上の登録
			if(burgerSumTax !=0) {
				for(int i=0;i<listbuger.size();i++) {
					bugerMenu=listbuger.get(i);

					int burgerResult = dao.insertBuger(id,bugerMenu.getBurger(),bugerMenu.getBurgerPrice(),bugerMenu.getBurgerCount(),date);

						if(burgerResult >0) {
							messageBurgerComplet = "DBへハンバーガー販売実績の登録に成功しました。";
					}
				}
			}

			//----------------サイドメニュー売上をDBに登録する----------------------
			//取得した売上idを使用してサイドメニュー売上の登録
			if(sideMenuSumTax != 0) {
				for(int i=0;i<listsideMenu.size();i++) {
					sideMenu=listsideMenu.get(i);

					int sideMenuResult = dao.insertSideMenu(id,sideMenu.getSideMenu(),sideMenu.getSideMenuPrice(),sideMenu.getSideMenuSize(),sideMenu.getSideMenuCount(),date);

						if(sideMenuResult >0) {
							messageSideMenuComplet = "DBへサイドメニュー販売実績の登録に成功しました。";
					}
				}
			}

			//----------------ドリンク売上をDBに登録する----------------------
			//取得した売上idを使用してドリンク売上の登録
			if(drinkSumTax != 0) {
				for(int i=0;i<listdrink.size();i++) {
					drinkMenu=listdrink.get(i);

					int drinkResult = dao.insertDrink(id,drinkMenu.getDrink(),drinkMenu.getDrinkPrice(),drinkMenu.getDrinkSize(),drinkMenu.getDrinkCount(),date);

						if(drinkResult >0) {
							messageDrinkComplet = "DBへドリンク販売実績の登録に成功しました。";
					}
				}
			}

		}else {
			error = "異常が発生しました。コードの確認をしてください。";
		}

		session.setAttribute("messageBurgerComplet", messageBurgerComplet);
		session.setAttribute("messageSideMenuComplet", messageSideMenuComplet);
		session.setAttribute("messageDrinkComplet", messageDrinkComplet);
		session.setAttribute("message", message);
		session.setAttribute("error", error);

		session.setAttribute("totalAll", totalAll);
		session.setAttribute("sales", sales);
		session.setAttribute("taxSum", taxSum);
		session.setAttribute("tax", tax);

		RequestDispatcher rd = request.getRequestDispatcher("./dbRegist.jsp");
		rd.forward(request, response);
	}
}
