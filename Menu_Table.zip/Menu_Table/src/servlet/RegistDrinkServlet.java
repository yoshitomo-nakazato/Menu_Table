package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.MenuEntity;

//@WebServlet("/RegistDrinkServlet")
public class RegistDrinkServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException,IOException{

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true);

		String drink = request.getParameter("drink");
		String drinkSize = request.getParameter("drinkSize");
		String drinkPricestr = request.getParameter("drinkPrice");
		Integer drinkPrice = Integer.parseInt(drinkPricestr);
		String drinkCountstr = request.getParameter("drinkCount");
		Integer drinkCount = Integer.parseInt(drinkCountstr);

		MenuEntity drinkmenu = new MenuEntity();
		List<MenuEntity> listdrink =(List<MenuEntity>)session.getAttribute("listdrink");

		//初回リスト登録
		if(listdrink == null) {
			listdrink =new ArrayList<MenuEntity>();
			drinkmenu.setDrink(drink);
			drinkmenu.setDrinkSize(drinkSize);
			drinkmenu.setDrinkPrice(drinkPrice);
			drinkmenu.setDrinkCount(drinkCount);
			listdrink.add(drinkmenu);

		//２回目以降
		}else {
			listdrink = (List<MenuEntity>)session.getAttribute("listdrink");
			drinkmenu.setDrink(drink);
			drinkmenu.setDrinkSize(drinkSize);
			drinkmenu.setDrinkPrice(drinkPrice);
			drinkmenu.setDrinkCount(drinkCount);
			listdrink.add(drinkmenu);
		}
		session.setAttribute("listdrink",listdrink);
		request.setAttribute("message","商品を買い物カゴに追加しました。");
		RequestDispatcher rd = request.getRequestDispatcher("./additionMenu.jsp");
		rd.forward(request, response);
	}
}
