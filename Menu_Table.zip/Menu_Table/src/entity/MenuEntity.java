package entity;

public class MenuEntity {

	String burger ;
	int burgerPrice ;
	int burgerCount ;
	
	String sideMenu ;
	String sideMenuSize ;
	int sideMenuPrice ;
	int sideMenuCount ;
	
	String drink ;
	String drinkSize ;
	int drinkPrice ;
	int drinkCount ;


	public String getBurger() {
		return burger;
	}
	public void setBurger(String burger) {
		this.burger = burger;
	}
	public int getBurgerPrice() {
		return burgerPrice;
	}
	public void setBurgerPrice(int burgerPrice) {
		this.burgerPrice = burgerPrice;
	}
	public int getBurgerCount() {
		return burgerCount;
	}
	public void setBurgerCount(int burgerCount) {
		this.burgerCount = burgerCount;
	}
	public String getSideMenu() {
		return sideMenu;
	}
	public void setSideMenu(String sideMenu) {
		this.sideMenu = sideMenu;
	}
	public String getSideMenuSize() {
		return sideMenuSize;
	}
	public void setSideMenuSize(String sideMenuSize) {
		this.sideMenuSize = sideMenuSize;
	}
	public int getSideMenuPrice() {
		return sideMenuPrice;
	}
	public void setSideMenuPrice(int sideMenuPrice) {
		this.sideMenuPrice = sideMenuPrice;
	}
	public int getSideMenuCount() {
		return sideMenuCount;
	}
	public void setSideMenuCount(int sideMenuCount) {
		this.sideMenuCount = sideMenuCount;
	}
	public String getDrink() {
		return drink;
	}
	public void setDrink(String drink) {
		this.drink = drink;
	}
	public String getDrinkSize() {
		return drinkSize;
	}
	public void setDrinkSize(String drinkSize) {
		this.drinkSize = drinkSize;
	}
	public int getDrinkPrice() {
		return drinkPrice;
	}
	public void setDrinkPrice(int drinkPrice) {
		this.drinkPrice = drinkPrice;
	}
	public int getDrinkCount() {
		return drinkCount;
	}
	public void setDrinkCount(int drinkCount) {
		this.drinkCount = drinkCount;
	}

}
